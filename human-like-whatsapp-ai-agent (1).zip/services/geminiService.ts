
import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysis, Message } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export async function analyzeAndGenerateResponse(
  userMessage: string | null,
  history: Message[],
  audioData?: { data: string; mimeType: string }
): Promise<AIAnalysis> {
  const model = "gemini-3-flash-preview";
  
  // Format history for context
  const historyText = history
    .slice(-10)
    .map(m => `${m.sender === 'user' ? 'Customer' : 'Agent'}: ${m.text}`)
    .join('\n');

  const systemInstruction = `
    You are a polite, friendly, and highly capable human receptionist for "SwiftSolutions Business Services".
    Your goal is to handle inquiries like a warm human. You are an expert linguist fluent in ALL major Indian languages.
    
    MULTILINGUAL RULES:
    1. Detect the language of the user's message (e.g., Hindi, Bengali, Telugu, Marathi, Tamil, Urdu, Gujarati, Kannada, Odia, Malayalam, Punjabi, etc.).
    2. RESPOND in the SAME language the user used. If they use "Hinglish" or "Kanglish" (English mix), respond with the same natural mix.
    3. Maintain a warm, helpful, and professional tone regardless of the language.
    
    GENERAL RULES:
    1. Speak naturally with human-like fillers (e.g., "Got it", "Zaroor", "Bilkul", "Theek hai").
    2. Use short, helpful sentences.
    3. Use emojis sparingly but naturally.
    4. Detect user intent: sales, support, appointment, pricing, greeting, angry_customer, follow_up.
    5. Detect user emotion: happy, neutral, frustrated, curious, urgent.
    6. If the user is very frustrated or requests a human specifically, set isEscalationNeeded to true.
    7. Use the provided context history to maintain conversation flow.
    8. IF AUDIO IS PROVIDED: Transcribe the audio exactly into the "transcription" field in its original language.

    Current Context:
    ${historyText}
  `;

  const parts: any[] = [];
  
  if (userMessage) {
    parts.push({ text: `User says: "${userMessage}"` });
  }

  if (audioData) {
    parts.push({
      inlineData: {
        data: audioData.data,
        mimeType: audioData.mimeType
      }
    });
    parts.push({ text: "Please transcribe the attached audio and respond to the user's request in the detected language." });
  }

  const response = await ai.models.generateContent({
    model,
    contents: { parts },
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          intent: { type: Type.STRING, description: "The primary intent identified" },
          emotion: { type: Type.STRING, description: "The user's emotional state" },
          urgency: { type: Type.STRING, enum: ["low", "medium", "high"] },
          confidence: { type: Type.NUMBER, description: "Confidence score between 0 and 1" },
          isEscalationNeeded: { type: Type.BOOLEAN, description: "True if human help is needed" },
          response: { type: Type.STRING, description: "The human-like response in the user's language" },
          detectedLanguage: { type: Type.STRING, description: "Name of the language detected (e.g., Hindi, Tamil, English)" },
          transcription: { type: Type.STRING, description: "Transcription of audio if provided" }
        },
        required: ["intent", "emotion", "urgency", "confidence", "isEscalationNeeded", "response", "detectedLanguage"],
        propertyOrdering: ["intent", "emotion", "urgency", "confidence", "isEscalationNeeded", "response", "detectedLanguage", "transcription"]
      }
    }
  });

  const result = JSON.parse(response.text.trim()) as AIAnalysis;
  return result;
}
