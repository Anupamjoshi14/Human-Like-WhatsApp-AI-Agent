
import React, { useState } from 'react';
import { ChatSession, Contact } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  contacts: Contact[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onStartNewChat: (contact: Contact) => void;
  onAddContact: (name: string, status: string) => void;
  onCreateGroup: (name: string, memberIds: string[]) => void;
}

type SidebarView = 'chats' | 'contacts' | 'newContact' | 'newGroup';

const Sidebar: React.FC<SidebarProps> = ({ 
  sessions, 
  contacts, 
  activeSessionId, 
  onSelectSession, 
  onStartNewChat,
  onAddContact,
  onCreateGroup
}) => {
  const [view, setView] = useState<SidebarView>('chats');
  const [searchQuery, setSearchQuery] = useState('');
  const [newContactName, setNewContactName] = useState('');
  const [newContactStatus, setNewContactStatus] = useState('');
  const [newGroupName, setNewGroupName] = useState('');
  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([]);

  const filteredSessions = sessions.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredContacts = contacts.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleContactClick = (contact: Contact) => {
    onStartNewChat(contact);
    setView('chats');
  };

  const handleAddContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newContactName.trim()) {
      onAddContact(newContactName, newContactStatus || 'Available');
      setNewContactName('');
      setNewContactStatus('');
      setView('contacts');
    }
  };

  const toggleMemberSelection = (id: string) => {
    setSelectedMemberIds(prev => 
      prev.includes(id) ? prev.filter(mid => mid !== id) : [...prev, id]
    );
  };

  const handleCreateGroupSubmit = () => {
    if (newGroupName.trim() && selectedMemberIds.length > 0) {
      onCreateGroup(newGroupName, selectedMemberIds);
      setNewGroupName('');
      setSelectedMemberIds([]);
      setView('chats');
    }
  };

  return (
    <div className="w-80 flex-shrink-0 bg-white border-r flex flex-col h-full transition-all duration-300">
      {/* Header */}
      <div className="p-4 bg-[#f0f2f5] flex items-center justify-between border-b min-h-[70px]">
        {view === 'chats' ? (
          <>
            <div className="flex items-center space-x-3">
              <img 
                src="https://picsum.photos/seed/reception/40/40" 
                className="w-10 h-10 rounded-full bg-gray-200 border border-gray-300" 
                alt="Profile" 
              />
              <h1 className="font-semibold text-gray-800">My Chats</h1>
            </div>
            <div className="flex space-x-4 text-gray-500">
              <button title="Status"><i className="fas fa-circle-notch"></i></button>
              <button 
                onClick={() => setView('contacts')}
                title="New Chat"
                className="hover:text-[#00a884] transition-colors"
              >
                <i className="fas fa-comment-alt"></i>
              </button>
              <button title="Menu"><i className="fas fa-ellipsis-v"></i></button>
            </div>
          </>
        ) : (
          <div className="flex items-center space-x-4 w-full">
            <button 
              onClick={() => {
                if (view === 'newContact' || view === 'newGroup') setView('contacts');
                else setView('chats');
              }}
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              <i className="fas fa-arrow-left"></i>
            </button>
            <h1 className="font-semibold text-gray-800 text-lg">
              {view === 'contacts' ? 'New Chat' : view === 'newContact' ? 'New Contact' : 'New Group'}
            </h1>
          </div>
        )}
      </div>

      {/* Conditional Rendering of Views */}
      <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col">
        {view === 'chats' && (
          <>
            <div className="p-3 bg-white">
              <div className="relative">
                <input 
                  type="text" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search or start new chat" 
                  className="w-full py-1.5 pl-10 pr-4 bg-[#f0f2f5] rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-green-200"
                />
                <i className="fas fa-search absolute left-3 top-2.5 text-gray-400 text-sm"></i>
              </div>
            </div>
            {filteredSessions.length > 0 ? (
              filteredSessions.sort((a, b) => b.lastTimestamp.getTime() - a.lastTimestamp.getTime()).map((session) => (
                <div 
                  key={session.id}
                  onClick={() => onSelectSession(session.id)}
                  className={`flex items-center p-3 cursor-pointer hover:bg-[#f5f6f6] border-b border-gray-50 transition-colors relative ${
                    activeSessionId === session.id ? 'bg-[#ebebeb]' : ''
                  }`}
                >
                  <div className="relative">
                    <img src={session.avatar} className="w-12 h-12 rounded-full mr-3 border border-gray-100" alt={session.name} />
                    {session.isGroup && (
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-[#00a884] rounded-full border-2 border-white flex items-center justify-center text-[10px] text-white">
                        <i className="fas fa-users"></i>
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline">
                      <h3 className="font-semibold text-gray-900 truncate">{session.name}</h3>
                      <span className="text-[11px] text-gray-500">
                        {session.lastTimestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="flex items-center space-x-1">
                      {session.status === 'escalated' && <i className="fas fa-user-headset text-[10px] text-orange-500"></i>}
                      <p className="text-sm text-gray-500 truncate">{session.lastMessage}</p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-10 text-center text-gray-400">
                <i className="fas fa-comments text-4xl mb-3 opacity-20"></i>
                <p className="text-sm">No chats found</p>
              </div>
            )}
          </>
        )}

        {view === 'contacts' && (
          <div className="flex flex-col">
            <div className="p-3 bg-white">
              <div className="relative">
                <input 
                  type="text" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search contacts" 
                  className="w-full py-1.5 pl-10 pr-4 bg-[#f0f2f5] rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-green-200"
                />
                <i className="fas fa-search absolute left-3 top-2.5 text-gray-400 text-sm"></i>
              </div>
            </div>
            <div 
              onClick={() => setView('newGroup')}
              className="flex items-center p-4 cursor-pointer hover:bg-[#f5f6f6] border-b border-gray-100"
            >
              <div className="w-12 h-12 rounded-full bg-[#00a884] flex items-center justify-center text-white mr-3">
                <i className="fas fa-users"></i>
              </div>
              <span className="font-semibold text-gray-800">New Group</span>
            </div>
            <div 
              onClick={() => setView('newContact')}
              className="flex items-center p-4 cursor-pointer hover:bg-[#f5f6f6] border-b border-gray-100"
            >
              <div className="w-12 h-12 rounded-full bg-[#00a884] flex items-center justify-center text-white mr-3">
                <i className="fas fa-user-plus"></i>
              </div>
              <span className="font-semibold text-gray-800">New Contact</span>
            </div>
            
            <div className="p-4 text-[#00a884] text-xs font-bold uppercase tracking-widest bg-white border-b border-gray-50">
              Contacts on WhatsApp
            </div>
            
            {filteredContacts.length > 0 ? (
              filteredContacts.sort((a, b) => a.name.localeCompare(b.name)).map((contact) => (
                <div 
                  key={contact.id}
                  onClick={() => handleContactClick(contact)}
                  className="flex items-center p-3 cursor-pointer hover:bg-[#f5f6f6] border-b border-gray-50 transition-colors"
                >
                  <img src={contact.avatar} className="w-12 h-12 rounded-full mr-3 border border-gray-100" alt={contact.name} />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 truncate">{contact.name}</h3>
                    <p className="text-sm text-gray-500 truncate">{contact.statusText}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-10 text-center text-gray-400">
                <p className="text-sm">No contacts found</p>
              </div>
            )}
          </div>
        )}

        {view === 'newContact' && (
          <form onSubmit={handleAddContactSubmit} className="p-6 flex flex-col space-y-6">
            <div className="flex flex-col items-center mb-4">
              <div className="w-24 h-24 bg-[#f0f2f5] rounded-full flex items-center justify-center text-gray-400 text-3xl mb-2 cursor-pointer hover:bg-gray-200 transition-colors">
                <i className="fas fa-camera"></i>
              </div>
              <span className="text-xs text-[#00a884] font-bold">ADD PHOTO</span>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="text-xs text-[#00a884] font-bold uppercase block mb-1">Full Name</label>
                <input 
                  autoFocus
                  type="text"
                  value={newContactName}
                  onChange={(e) => setNewContactName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full border-b-2 border-gray-200 py-2 focus:border-[#00a884] outline-none transition-colors text-gray-800"
                />
              </div>
              <div>
                <label className="text-xs text-[#00a884] font-bold uppercase block mb-1">Status / About</label>
                <input 
                  type="text"
                  value={newContactStatus}
                  onChange={(e) => setNewContactStatus(e.target.value)}
                  placeholder="Hey there! I am using WhatsApp."
                  className="w-full border-b-2 border-gray-200 py-2 focus:border-[#00a884] outline-none transition-colors text-gray-800"
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={!newContactName.trim()}
              className="w-full py-3 bg-[#00a884] text-white rounded-lg font-bold shadow-md hover:bg-[#008f70] disabled:bg-gray-300 disabled:shadow-none transition-all mt-auto"
            >
              SAVE CONTACT
            </button>
          </form>
        )}

        {view === 'newGroup' && (
          <div className="flex flex-col h-full">
            <div className="p-4 space-y-4 border-b">
              <div className="flex items-center space-x-3">
                 <div className="w-12 h-12 bg-[#f0f2f5] rounded-full flex items-center justify-center text-gray-400">
                  <i className="fas fa-camera"></i>
                </div>
                <input 
                  autoFocus
                  type="text"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="Group Subject"
                  className="flex-1 border-b-2 border-gray-200 py-2 focus:border-[#00a884] outline-none transition-colors text-gray-800"
                />
              </div>
              {selectedMemberIds.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {selectedMemberIds.map(id => {
                    const contact = contacts.find(c => c.id === id);
                    return (
                      <div key={id} className="bg-gray-100 rounded-full px-2 py-1 flex items-center space-x-1 border border-gray-200">
                        <span className="text-[10px] font-semibold">{contact?.name}</span>
                        <button onClick={() => toggleMemberSelection(id)} className="text-gray-400 hover:text-red-500">
                          <i className="fas fa-times-circle"></i>
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="flex-1 overflow-y-auto">
              <div className="p-3 text-xs text-[#00a884] font-bold uppercase">Select Contacts</div>
              {filteredContacts.map(contact => (
                <div 
                  key={contact.id}
                  onClick={() => toggleMemberSelection(contact.id)}
                  className="flex items-center p-3 cursor-pointer hover:bg-[#f5f6f6] border-b border-gray-50"
                >
                  <div className="relative mr-3">
                    <img src={contact.avatar} className="w-12 h-12 rounded-full" alt={contact.name} />
                    {selectedMemberIds.includes(contact.id) && (
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-[#00a884] rounded-full border-2 border-white flex items-center justify-center text-[10px] text-white">
                        <i className="fas fa-check"></i>
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{contact.name}</h3>
                    <p className="text-xs text-gray-500">{contact.statusText}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 bg-[#f0f2f5] flex justify-center">
              <button 
                onClick={handleCreateGroupSubmit}
                disabled={!newGroupName.trim() || selectedMemberIds.length === 0}
                className="w-14 h-14 bg-[#00a884] text-white rounded-full flex items-center justify-center shadow-lg hover:bg-[#008f70] disabled:bg-gray-300 disabled:shadow-none transition-all"
              >
                <i className="fas fa-arrow-right"></i>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;
