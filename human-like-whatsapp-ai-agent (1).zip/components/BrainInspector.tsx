
import React from 'react';
import { Message } from '../types';

interface BrainInspectorProps {
  lastMessageAnalysis?: Message;
}

const BrainInspector: React.FC<BrainInspectorProps> = ({ lastMessageAnalysis }) => {
  return (
    <div className="w-72 bg-[#f8f9fa] border-l flex flex-col h-full overflow-hidden">
      <div className="p-4 bg-white border-b flex items-center space-x-2">
        <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
          <i className="fas fa-brain"></i>
        </div>
        <h2 className="font-semibold text-gray-800">Agent Brain Layer</h2>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <section>
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Orchestration Steps</h3>
          <div className="space-y-3">
            {[
              { icon: 'fa-language', label: 'Multilingual Detection', color: 'indigo', status: 'Active' },
              { icon: 'fa-microscope', label: 'Intent Analysis', color: 'blue', status: 'Completed' },
              { icon: 'fa-memory', label: 'Context Retrieval', color: 'purple', status: 'Completed' },
              { icon: 'fa-magic', label: 'Natural Reply Gen', color: 'pink', status: 'Completed' },
            ].map((step, i) => (
              <div key={i} className="flex items-center space-x-3 bg-white p-2 rounded-lg shadow-sm">
                <div className={`w-8 h-8 rounded flex items-center justify-center text-xs bg-${step.color}-50 text-${step.color}-600`}>
                  <i className={`fas ${step.icon}`}></i>
                </div>
                <div className="flex-1">
                  <p className="text-[12px] font-semibold text-gray-700">{step.label}</p>
                  <p className="text-[10px] text-gray-400">{step.status}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Live Analysis</h3>
          {lastMessageAnalysis ? (
            <div className="bg-white rounded-lg shadow-sm border border-blue-50 p-3 space-y-4">
              <div>
                <p className="text-[11px] text-gray-400 mb-1">Detected Language</p>
                <div className="flex items-center space-x-2">
                   <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 rounded text-xs font-bold uppercase">
                    {lastMessageAnalysis.detectedLanguage || 'Detecting...'}
                  </span>
                </div>
              </div>

              <div>
                <p className="text-[11px] text-gray-400 mb-1">Detected Intent</p>
                <div className="flex items-center space-x-2">
                   <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-bold capitalize">
                    {lastMessageAnalysis.intent || 'Unknown'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-[11px] text-gray-400 mb-1">Emotion</p>
                  <span className="text-sm font-semibold text-gray-700 capitalize">
                    {lastMessageAnalysis.emotion || 'Neutral'}
                  </span>
                </div>
                <div>
                  <p className="text-[11px] text-gray-400 mb-1">Urgency</p>
                  <span className={`text-sm font-semibold capitalize ${
                    lastMessageAnalysis.urgency === 'high' ? 'text-red-500' : 
                    lastMessageAnalysis.urgency === 'medium' ? 'text-orange-500' : 'text-green-500'
                  }`}>
                    {lastMessageAnalysis.urgency || 'Low'}
                  </span>
                </div>
              </div>

              <div>
                <p className="text-[11px] text-gray-400 mb-1">Memory Utilization</p>
                <div className="w-full bg-gray-100 rounded-full h-1.5">
                  <div className="bg-purple-500 h-1.5 rounded-full" style={{ width: '85%' }}></div>
                </div>
                <p className="text-[10px] text-gray-400 mt-1">Context Window: 10/10 msgs</p>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm p-4 text-center">
              <p className="text-xs text-gray-400 italic">Waiting for incoming user message...</p>
            </div>
          )}
        </section>

        <section className="bg-blue-600 rounded-xl p-4 text-white">
          <h4 className="text-sm font-bold mb-1">Monetization Peak</h4>
          <p className="text-[11px] opacity-80 mb-3">AI Receptionist for SMBs is active.</p>
          <div className="flex justify-between items-end">
            <div>
              <p className="text-[10px] opacity-70">Daily Savings</p>
              <p className="text-lg font-bold">₹4,250</p>
            </div>
            <i className="fas fa-chart-line text-2xl opacity-40"></i>
          </div>
        </section>
      </div>
    </div>
  );
};

export default BrainInspector;
