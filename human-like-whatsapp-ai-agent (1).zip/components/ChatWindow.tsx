
import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../types';

interface ChatWindowProps {
  sessionName: string;
  avatar: string;
  messages: Message[];
  onSendMessage: (text: string) => void;
  onSendVoice: (audioBase64: string, mimeType: string) => void;
  onEscalate: () => void;
  onStartCall: () => void;
  isEscalated: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ 
  sessionName, 
  avatar, 
  messages, 
  onSendMessage, 
  onSendVoice,
  onEscalate,
  onStartCall,
  isEscalated
}) => {
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (inputText.trim()) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/ogg';
      const mediaRecorder = new MediaRecorder(stream, { mimeType });
      
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          const base64Audio = (reader.result as string).split(',')[1];
          onSendVoice(base64Audio, mimeType);
        };
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      timerRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Microphone access is required for voice messages.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.onstop = null;
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSend();
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#f0f2f5]">
      {/* Header */}
      <div className="p-3 bg-[#f0f2f5] flex items-center justify-between border-b shadow-sm z-10">
        <div className="flex items-center">
          <img src={avatar} className="w-10 h-10 rounded-full mr-3" alt={sessionName} />
          <div>
            <h2 className="font-semibold text-gray-800 leading-tight">{sessionName}</h2>
            <p className="text-[12px] text-gray-500">
              {isEscalated ? (
                <span className="text-orange-600 font-medium">Escalated to Human</span>
              ) : 'AI Receptionist Active'}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-5 text-gray-500 pr-2">
          <button onClick={onStartCall} className="hover:text-[#00a884] transition-colors" title="Start Call">
            <i className="fas fa-phone-alt"></i>
          </button>
          <button className="hover:text-[#00a884] transition-colors" title="Video Call">
            <i className="fas fa-video"></i>
          </button>
          <button title="Search"><i className="fas fa-search"></i></button>
          {!isEscalated && (
            <button 
              onClick={onEscalate}
              className="px-3 py-1 bg-white border border-gray-300 rounded-full text-xs text-orange-600 font-semibold hover:bg-orange-50 transition-colors"
            >
              Transfer
            </button>
          )}
          <button title="Menu"><i className="fas fa-ellipsis-v"></i></button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 whatsapp-bg relative">
        <div className="max-w-2xl mx-auto space-y-4">
          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex ${msg.sender === 'user' ? 'justify-end' : msg.sender === 'system' ? 'justify-center' : 'justify-start'}`}
            >
              {msg.sender === 'system' ? (
                <div className="bg-[#fff9c4] text-[#795548] text-[12px] py-1 px-3 rounded-lg shadow-sm font-medium uppercase tracking-wider">
                  {msg.text}
                </div>
              ) : (
                <div 
                  className={`max-w-[85%] rounded-lg px-3 py-2 shadow-sm text-sm relative group ${
                    msg.sender === 'user' 
                      ? 'bg-[#dcf8c6] rounded-tr-none' 
                      : 'bg-white rounded-tl-none'
                  }`}
                >
                  {msg.isTyping ? (
                    <div className="flex space-x-1 py-1 px-2">
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:-.15s]"></div>
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:-.3s]"></div>
                    </div>
                  ) : (
                    <>
                      {msg.isVoice ? (
                        <div className="flex flex-col min-w-[260px]">
                          {/* Voice Header Indicator */}
                          <div className={`flex items-center space-x-2 mb-2 ${msg.sender === 'user' ? 'text-green-700' : 'text-blue-600'}`}>
                            <div className="relative">
                               <i className="fas fa-microphone text-xs"></i>
                               {msg.sender === 'agent' && <div className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 rounded-full border border-white"></div>}
                            </div>
                            <span className="text-[10px] font-bold uppercase tracking-widest">
                              {msg.sender === 'user' ? 'Voice Message' : 'AI Assistant Voice'}
                            </span>
                          </div>

                          {/* Transcribed Text (Immediately below indicator) */}
                          <div className="mb-3 pl-1">
                            {msg.text ? (
                              <p className="text-gray-800 text-[14px] leading-snug">
                                {msg.text}
                              </p>
                            ) : (
                              <div className="flex items-center space-x-2 py-1">
                                <div className="flex space-x-1">
                                  <div className="w-1 h-1 bg-gray-400 rounded-full animate-pulse"></div>
                                  <div className="w-1 h-1 bg-gray-400 rounded-full animate-pulse delay-75"></div>
                                  <div className="w-1 h-1 bg-gray-400 rounded-full animate-pulse delay-150"></div>
                                </div>
                                <p className="text-gray-400 text-[12px] italic">
                                  Processing audio...
                                </p>
                              </div>
                            )}
                          </div>

                          {/* Simulated Audio Player (WhatsApp Style) */}
                          <div className="flex items-center space-x-3 bg-black/5 rounded-full px-3 py-2">
                            <button className={`w-8 h-8 rounded-full flex items-center justify-center text-white shrink-0 shadow-sm ${msg.sender === 'user' ? 'bg-[#00a884]' : 'bg-blue-500'}`}>
                              <i className="fas fa-play text-[10px] ml-0.5"></i>
                            </button>
                            <div className="flex-1 flex items-center space-x-0.5 h-5">
                              {[0.3, 0.6, 0.4, 0.8, 0.5, 0.2, 0.7, 0.4, 0.6, 0.4, 0.7, 0.3, 0.5, 0.4].map((h, i) => (
                                <div 
                                  key={i} 
                                  className={`w-[2px] rounded-full transition-all ${msg.sender === 'user' ? 'bg-green-400' : 'bg-blue-300'}`}
                                  style={{ height: `${h * 100}%` }}
                                ></div>
                              ))}
                            </div>
                            <span className="text-[10px] text-gray-500 font-medium tabular-nums">0:04</span>
                          </div>
                        </div>
                      ) : (
                        <p className="text-gray-800 leading-relaxed break-words whitespace-pre-wrap">{msg.text}</p>
                      )}
                      
                      <div className="flex items-center justify-end mt-1 space-x-1">
                        <span className="text-[10px] text-gray-400">
                          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        {msg.sender === 'user' && (
                          <i className="fas fa-check-double text-[10px] text-blue-400"></i>
                        )}
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="p-3 bg-[#f0f2f5] flex items-center space-x-3">
        {isRecording ? (
          <div className="flex-1 flex items-center bg-white rounded-full px-4 py-2 shadow-sm space-x-3 transition-all border border-red-100">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-mono text-gray-700 font-bold">{formatTime(recordingTime)}</span>
            <div className="flex-1 text-gray-400 text-xs truncate italic">Recording...</div>
            <button 
              onClick={cancelRecording} 
              className="text-red-500 font-semibold text-sm hover:underline"
            >
              Cancel
            </button>
          </div>
        ) : (
          <>
            <button className="text-gray-500 text-xl hover:text-gray-700 transition-colors">
              <i className="far fa-smile"></i>
            </button>
            <button className="text-gray-500 text-xl hover:text-gray-700 transition-colors">
              <i className="fas fa-paperclip"></i>
            </button>
            <div className="flex-1">
              <input 
                type="text" 
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type a message" 
                className="w-full py-2 px-4 bg-white rounded-full text-sm focus:outline-none shadow-sm border border-transparent focus:border-green-200 transition-all"
              />
            </div>
          </>
        )}
        
        <button 
          onClick={isRecording ? stopRecording : (inputText.trim() ? handleSend : startRecording)}
          className={`flex items-center justify-center w-11 h-11 rounded-full text-white shadow-md transition-all transform active:scale-95 ${
            isRecording ? 'bg-red-500 animate-pulse' : 'bg-[#00a884] hover:bg-[#008f70]'
          }`}
          title={isRecording ? "Stop Recording" : (inputText.trim() ? "Send Message" : "Voice Message")}
        >
          {isRecording ? (
            <i className="fas fa-stop text-sm"></i>
          ) : (
            inputText.trim() ? <i className="fas fa-paper-plane text-sm"></i> : <i className="fas fa-microphone text-sm"></i>
          )}
        </button>
      </div>
    </div>
  );
};

export default ChatWindow;
