
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';

interface VoiceCallProps {
  sessionName: string;
  avatar: string;
  onEndCall: () => void;
}

const VoiceCall: React.FC<VoiceCallProps> = ({ sessionName, avatar, onEndCall }) => {
  const [status, setStatus] = useState<'connecting' | 'connected' | 'ended'>('connecting');
  const [callTime, setCallTime] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [showEndConfirmation, setShowEndConfirmation] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sessionRef = useRef<any>(null);
  const timerRef = useRef<number | null>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Helper: Decode Base64
  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  // Helper: Encode to Base64
  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  // Helper: Raw PCM to AudioBuffer
  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const createBlob = (data: Float32Array): Blob => {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
      int16[i] = data[i] * 32768;
    }
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  };

  useEffect(() => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
    const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    audioContextRef.current = outputAudioContext;

    const startSession = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        const sessionPromise = ai.live.connect({
          model: 'gemini-2.5-flash-native-audio-preview-09-2025',
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } },
            },
            systemInstruction: 'You are a warm, human receptionist for SwiftSolutions. You are on a live voice call. Keep responses concise, helpful, and natural.',
          },
          callbacks: {
            onopen: () => {
              setStatus('connected');
              const source = inputAudioContext.createMediaStreamSource(stream);
              const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
              
              scriptProcessor.onaudioprocess = (e) => {
                if (isMuted) return;
                const inputData = e.inputBuffer.getChannelData(0);
                const pcmBlob = createBlob(inputData);
                sessionPromise.then(session => {
                  session.sendRealtimeInput({ media: pcmBlob });
                });
              };

              source.connect(scriptProcessor);
              scriptProcessor.connect(inputAudioContext.destination);
              
              timerRef.current = window.setInterval(() => {
                setCallTime(prev => prev + 1);
              }, 1000);
            },
            onmessage: async (message: LiveServerMessage) => {
              const audioBase64 = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
              if (audioBase64) {
                nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
                const audioBuffer = await decodeAudioData(decode(audioBase64), outputAudioContext, 24000, 1);
                const source = outputAudioContext.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(outputAudioContext.destination);
                source.start(nextStartTimeRef.current);
                nextStartTimeRef.current += audioBuffer.duration;
                sourcesRef.current.add(source);
                source.onended = () => sourcesRef.current.delete(source);
              }

              if (message.serverContent?.interrupted) {
                sourcesRef.current.forEach(s => s.stop());
                sourcesRef.current.clear();
                nextStartTimeRef.current = 0;
              }
            },
            onerror: (e) => console.error('Live API Error', e),
            onclose: () => onEndCall(),
          },
        });

        sessionRef.current = await sessionPromise;
      } catch (err) {
        console.error('Failed to start call', err);
        onEndCall();
      }
    };

    startSession();

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (audioContextRef.current) audioContextRef.current.close();
      if (inputAudioContext) inputAudioContext.close();
      if (sessionRef.current) sessionRef.current.close();
    };
  }, []);

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndCallClick = () => {
    setShowEndConfirmation(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-[#075e54] text-white p-12">
      <div className="flex flex-col items-center mt-10">
        <div className="text-sm opacity-80 uppercase tracking-widest mb-2 flex items-center">
          <i className="fas fa-lock text-[10px] mr-2"></i>
          End-to-End Encrypted
        </div>
        <h2 className="text-3xl font-normal mb-2">{sessionName}</h2>
        <p className="text-lg opacity-80">
          {status === 'connecting' ? 'Calling...' : formatTime(callTime)}
        </p>
      </div>

      <div className="relative">
        <div className="w-48 h-48 rounded-full overflow-hidden border-4 border-[#128c7e] shadow-2xl">
          <img src={avatar} alt={sessionName} className="w-full h-full object-cover" />
        </div>
        {status === 'connected' && (
           <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex space-x-1">
             {[0, 1, 2].map(i => (
               <div 
                 key={i} 
                 className="w-1.5 h-6 bg-white rounded-full animate-bounce" 
                 style={{ animationDelay: `${i * 0.1}s` }}
               ></div>
             ))}
           </div>
        )}
      </div>

      <div className="w-full max-w-sm flex justify-around items-center mb-10">
        <button 
          onClick={() => setIsMuted(!isMuted)}
          className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors ${isMuted ? 'bg-white text-[#075e54]' : 'bg-[#128c7e] hover:bg-[#128c7e]/80'}`}
        >
          <i className={`fas ${isMuted ? 'fa-microphone-slash' : 'fa-microphone'} text-xl`}></i>
        </button>
        
        <button 
          onClick={handleEndCallClick}
          className="w-20 h-20 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center shadow-xl transform active:scale-95 transition-all"
        >
          <i className="fas fa-phone-slash text-3xl rotate-[135deg]"></i>
        </button>

        <button className="w-16 h-16 bg-[#128c7e] hover:bg-[#128c7e]/80 rounded-full flex items-center justify-center">
          <i className="fas fa-volume-up text-xl"></i>
        </button>
      </div>

      {/* Confirmation Dialog */}
      {showEndConfirmation && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 backdrop-blur-sm p-6 animate-in fade-in duration-200">
          <div className="bg-white text-gray-800 rounded-2xl w-full max-w-xs overflow-hidden shadow-2xl scale-in-center animate-in zoom-in-95 duration-200">
            <div className="p-6 text-center">
              <h3 className="text-lg font-semibold mb-2">End Call?</h3>
              <p className="text-sm text-gray-500">Are you sure you want to end this call?</p>
            </div>
            <div className="flex border-t border-gray-100">
              <button 
                onClick={() => setShowEndConfirmation(false)}
                className="flex-1 py-4 text-sm font-semibold border-r border-gray-100 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={onEndCall}
                className="flex-1 py-4 text-sm font-semibold text-red-600 hover:bg-red-50 transition-colors"
              >
                End Call
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VoiceCall;
